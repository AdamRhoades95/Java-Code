package com.akgames.animation;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.net.URISyntaxException;


@SuppressWarnings("ALL")
public class MainActivity extends Activity {
    private GameView game;
//    DatabaseReference mRootref = FirebaseDatabase.getInstance().getReference();
//    DatabaseReference mConditionRef = mRootref.child("points");

    //private Camera mCamera;
//    private Handler handler = new Handler();
//    private final static long interval = 30;
//    private Object GameView;
    private static final int RC_SIGN_IN = 9001;

    // Client used to sign in with Google APIs
//    private GoogleSignInClient mGoogleSignInClient = null;
//    @Override
//    protected void onSaveInstanceState(Bundle outState) {
//        super.onSaveInstanceState(outState);
//        outState.p
//                putString("a1", String.valueOf(A1.getText()));
//    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


            Intent intent = getIntent();


        try {
            //mGoogleSignInClient = GoogleSignIn.getClient(this, GoogleSignInOptions.DEFAULT_GAMES_SIGN_IN);
        }catch(Exception e){

        }
        //        Window window = getWindow();
//        window.setFlags(
//                WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN
//        );

        game = new GameView(this);
        game.setUser(intent.getStringExtra("username"));
        setContentView(game);
    }

    @Override
    protected void onStart() {
        Log.d("MainActivity.java", "onStart()");
        super.onStart();

        // Check for existing Google Sign In account, if the user is already signed in
// the GoogleSignInAccount will be non-null.
        //GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        //updateUI(account);
    }

    @Override
    protected void onResume() {
        Log.d("MainActivity.java", "onResume()");
        super.onResume();
        game.resume();
//        if (mCamera == null) {
//            initializeCamera();// Local method to handle camera init
//        }
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        try{
        super.onSaveInstanceState(outState);
        game.pause();
    }catch (Exception e){
        System.out.println(e);

    }
        //outState.putParcelable("parcelable", model);
        //game.saveState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        try{
        //super.onCreate(savedInstanceState);
        super.onRestoreInstanceState(savedInstanceState);
        game = new GameView(this);
        game.resume();
        //game.restoreState(savedInstanceState);
        setContentView(game);
    }catch (Exception e){
        System.out.println(e);
    }
        //Model model = savedInstanceState.getParcelable("parcelable");
    }
//    private void initializeCamera() {
//
//    }

    @Override
    protected void onPause() {
        Log.d("MainActivity.java", "onPause()");
        try {
            //game.pause();
            super.onPause();
            game.pause();
        }catch (Exception e){
            System.out.println(e);
        }
//        if (mCamera != null) {
//            mCamera.release();
//            mCamera = null;
//        }
    }

    @Override
    protected void onStop() {
        Log.d("MainActivity.java", "onStop()");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d("MainActivity.java", "onDestroy()");
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // Comment out "super.onBackPressed()" to disable button
        //super.onBackPressed();
    }
}