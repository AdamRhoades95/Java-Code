package com.akgames.animation;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;

public class FireBTN extends View {
    private final DisplayMetrics displayMetrics;
    //private final int height,width;
    private Bitmap fireBTNSet, fireBTNGo,swap,reload,bag;
    private int positionX, positionY;
    private int fireBTNH, fireBTNW;
    private int swapW, swapH;
    private int reloadW, reloadH;

    public FireBTN(Context context, int positionX, int positionY) {
        super(context);
        displayMetrics = new DisplayMetrics();
//        ((Activity) getContext()).getWindowManager()
//                .getDefaultDisplay()
//                .getMetrics(displayMetrics);
//        this.height = displayMetrics.heightPixels;
//        this.width = displayMetrics.widthPixels;
        this.positionX = positionX;
        this.positionY = positionY;
        fireBTNSet = BitmapFactory.decodeResource(getResources(),R.drawable.fireready);
        //Bitmap fireBTNSet1 = Bitmap.createBitmap(fireBTNSet,positionX-190,positionY-180,150,100);
        fireBTNGo = BitmapFactory.decodeResource(getResources(),R.drawable.fired);
        swap = BitmapFactory.decodeResource(getResources(),R.drawable.gunswap60);
        //bag = BitmapFactory.decodeResource(getResources(),R.drawable.bag60);
        reload = BitmapFactory.decodeResource(getResources(),R.drawable.reload60);

        fireBTNH = fireBTNSet.getHeight();
        fireBTNW = fireBTNSet.getWidth();
        swapH = swap.getHeight();
        swapW = swap.getWidth();
        reloadH = reload.getHeight();
        reloadW = reload.getWidth();


    }



    public int getFireBTNH() {
        return fireBTNH;
    }

    public int getFireBTNW() {
        return fireBTNW;
    }

    public int getSwapW() {
        return swapW;
    }

    public int getSwapH() {
        return swapH;
    }

    public int getReloadW() {
        return reloadW;
    }

    public int getReloadH() {
        return reloadH;
    }

    public void Draw(Canvas canvas, int check) {
        super.draw(canvas);
        if(check == 0) {
            canvas.drawBitmap(fireBTNSet, positionX-fireBTNW, positionY-(fireBTNH+80), null);
        }
        else{
            canvas.drawBitmap(fireBTNGo, positionX-fireBTNW, positionY-(fireBTNH+80), null);
        }
        canvas.drawBitmap(swap, positionX-(swapW), positionY-(swapH+(fireBTNH+80)), null);
        canvas.drawBitmap(reload, positionX-(reloadW+swapW+20), positionY-(reloadH+(fireBTNH+80)), null);
        //canvas.drawBitmap(bag, positionX-320, positionY-180, null);
    }

}
